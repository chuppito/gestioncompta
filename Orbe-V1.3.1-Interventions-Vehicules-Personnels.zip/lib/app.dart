import 'package:flutter/material.dart';

import 'features/orbe_viewer/presentation/pages/orbe_webview_page.dart';

class OrbeApp extends StatelessWidget {
  const OrbeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Orbe',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0E8C6B), // vert proche du header Orbe
        useMaterial3: true,
      ),
      home: const OrbeWebViewPage(),
    );
  }
}
