import 'package:flutter/services.dart';

/// Clé utilisée pour mémoriser le nom saisi par chaque utilisateur de l'app,
/// afin qu'il n'ait à le taper qu'une seule fois (utile pour la distribuer
/// telle quelle à des collègues, sans nom codé en dur dedans).
const String kWatchedNamePrefsKey = 'orbe_viewer_watch_name';

/// Canal natif utilisé pour récupérer le paramètre "watch_name" transmis par
/// une autre app (ex: APK Intervention) au lancement — voir MainActivity.kt.
const MethodChannel intentChannel = MethodChannel('com.tomtom.orbe/intent');

/// URL de destination : page Notifications / Accusés de réception d'Orbe.
const String kOrbeUrl =
    'https://orbe.aum.bio/#/index/notifications/acknowledgements';

/// URL de la page Cartes/Synoptiques avec le statut opérationnel, utilisée
/// pour aller chercher le ticket de départ d'un centre.
const String kOrbeMapUrl =
    'https://orbe.aum.bio/#/index/homepage?mapOption=operational_status&dashboardOpened=yes';

/// Clé de préférence pour mémoriser le dernier centre consulté (ex: MOIRANS).
const String kLastCenterPrefsKey = 'orbe_viewer_last_center';
