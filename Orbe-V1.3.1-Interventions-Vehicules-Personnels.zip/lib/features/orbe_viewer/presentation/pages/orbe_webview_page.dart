import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart'
    show AndroidWebViewController, AndroidWebViewPlatform;

import '../../../../core/constants/orbe_constants.dart';

class OrbeWebViewPage extends StatefulWidget {
  const OrbeWebViewPage({super.key});

  @override
  State<OrbeWebViewPage> createState() => _OrbeWebViewPageState();
}

class _OrbeWebViewPageState extends State<OrbeWebViewPage> {
  late final WebViewController _controller;
  double _progress = 0;
  bool _hasError = false;
  int _forceRouteAttempts = 0;
  static const int _maxForceRouteAttempts = 5;
  double _zoomPercent = 50;
  final List<String> _consoleLogs = [];

  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();
  Timer? _pollTimer;
  final Set<String> _notifiedInterventionIds = {};
  bool _notificationsReady = false;
  bool _pageReady = false;
  bool _pendingNexsisScan = false;
  bool _nexsisScanRunning = false;
  String _watchedName = '';
  String? _lastNotifiedInterventionId;
  bool _ticketModeActive = false;
  String _lastCenterName = '';

  @override
  void initState() {
    super.initState();

    _initWatchedName();
    _initNotifications();
    _loadLastCenter();

    // Active le débogage distant de la WebView (chrome://inspect depuis un
    // PC avec le téléphone branché en USB) pour pouvoir comparer le rendu
    // réel avec celui d'un onglet Chrome classique.
    if (WebViewPlatform.instance is AndroidWebViewPlatform) {
      AndroidWebViewController.enableDebugging(true);
    }

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      // Certains sites détectent le marqueur "wv" du User-Agent WebView par
      // défaut et servent un comportement différent (redirection vers une
      // page par défaut). On se fait donc passer pour un Chrome mobile
      // standard afin qu'Orbe traite l'app comme un onglet de navigateur
      // classique et respecte le hash de l'URL demandée.
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
      )
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            setState(() => _progress = progress / 100);
          },
          onPageStarted: (_) {
            _pageReady = false;
            setState(() => _hasError = false);
            _disableTextAutosizing();
          },
          onPageFinished: (_) {
            _pageReady = true;
            if (_ticketModeActive) {
              // Pendant la récupération du ticket, on navigue volontairement
              // ailleurs (page carte) : on ne force pas le retour sur
              // Notifications, on garde juste les correctifs d'affichage.
              _disableTextAutosizing();
              _triggerReflow();
              return;
            }
            _ensureCorrectRoute();
            _disableTextAutosizing();
            _hideDescriptionText();
            _selectSortiesEnCoursTab();
            _triggerReflow();
            _applyZoom(_zoomPercent);
            // Scan immédiat dès que la page est prête, sans attendre le
            // premier cycle du minuteur périodique (utile quand l'app est
            // lancée pile pour cette alerte, via APK Intervention).
            _checkForWatchedCrewName();
            if (_pendingNexsisScan) {
              _pendingNexsisScan = false;
              _runNexsisTriggeredScan();
            }
          },
          onWebResourceError: (error) {
            // On ignore les erreurs mineures de sous-ressources, on ne
            // signale que les échecs de chargement de la page principale.
            if (error.isForMainFrame ?? true) {
              setState(() => _hasError = true);
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(kOrbeUrl));

    // Capture les messages console (erreurs JS, ressources bloquées, etc.)
    // pour pouvoir les consulter directement dans l'app.
    final platformController = _controller.platform;
    if (platformController is AndroidWebViewController) {
      platformController.setOnConsoleMessage((message) {
        _consoleLogs.add('[${message.level.name}] ${message.message}');
        if (_consoleLogs.length > 200) {
          _consoleLogs.removeAt(0);
        }
      });
    }

    // Filet de sécurité : le déclencheur principal vient maintenant de
    // NotificationListenerService lorsqu'une notification NexSIS arrive.
    // On garde un contrôle périodique beaucoup plus espacé au cas où
    // Android aurait interrompu le service ou si Orbe a changé sans
    // notification NexSIS associée.
    _pollTimer = Timer.periodic(
      const Duration(seconds: 60),
      (_) => _checkForWatchedCrewName(),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _reload() async {
    setState(() => _hasError = false);
    _forceRouteAttempts = 0;
    await _controller.loadRequest(Uri.parse(kOrbeUrl));
  }

  // Certaines SPA en hash-routing redirigent vers une page par défaut
  // (ex: le tableau de bord) juste après le chargement initial, une fois
  // la session/l'auth vérifiée côté client — ce qui écrase le hash qu'on
  // avait demandé. On vérifie donc l'URL réelle après chaque chargement
  // et on reforce la bonne route si besoin, avec un léger délai pour
  // laisser la redirection interne se produire avant de la corriger.
  Future<void> _ensureCorrectRoute() async {
    if (_forceRouteAttempts >= _maxForceRouteAttempts) return;
    _forceRouteAttempts++;

    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    final currentUrl = await _controller.currentUrl();
    if (currentUrl != null &&
        !currentUrl.contains('notifications/acknowledgements')) {
      await _controller.loadRequest(Uri.parse(kOrbeUrl));
    }
  }

  // Android WebView gonfle automatiquement la taille du texte sur les
  // colonnes étroites ("text autosizing"), indépendamment du textZoom —
  // ce qui casse les mises en page à largeurs fixes (chevauchements).
  // Chrome (l'appli) ne fait pas ça de la même façon, d'où la différence
  // de rendu. On neutralise ce comportement via CSS.
  Future<void> _disableTextAutosizing() async {
    await _controller.runJavaScript('''
      (function() {
        var id = 'orbe-viewer-text-adjust-fix';
        if (document.getElementById(id)) return;
        var style = document.createElement('style');
        style.id = id;
        style.innerHTML = 'html, body, * { -webkit-text-size-adjust: 100% !important; text-size-adjust: 100% !important; }';
        (document.head || document.documentElement).appendChild(style);
      })();
    ''');
  }

  // Au premier rendu, la vue WebView n'a parfois pas encore sa taille
  // définitive quand la page calcule sa mise en page (colonnes/flex), ce
  // qui produit un affichage chevauché tant qu'aucun vrai resize ne
  // survient. On simule cet événement pour forcer le recalcul du CSS.
  Future<void> _triggerReflow() async {
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    await _controller.runJavaScript(
      "window.dispatchEvent(new Event('resize'));",
    );
  }

  Future<void> _initWatchedName() async {
    final prefs = await SharedPreferences.getInstance();

    // Écoute les relances de l'app par une autre app (app déjà ouverte).
    intentChannel.setMethodCallHandler((call) async {
      if (call.method == 'onWatchNameUpdated') {
        final name = call.arguments as String?;
        if (name != null && name.trim().isNotEmpty) {
          await _setWatchedName(name.trim(), prefs);
          _checkForWatchedCrewName();
        }
      } else if (call.method == 'onNexsisNotification') {
        _handleNexsisNotification();
      }
    });

    // On récupère d'abord le nom surveillé.
    // IMPORTANT : si NexSIS a lancé Orbe à froid, l'événement peut arriver
    // avant que _watchedName soit restauré. Dans ce cas le scan serait
    // abandonné trop tôt. On mémorise donc l'événement et on le traite
    // seulement après avoir restauré le nom.

    // 1) Paramètre du lancement initial (ex: transmis par APK Intervention).
    String? name;
    try {
      name = await intentChannel.invokeMethod<String>('getWatchName');
    } on PlatformException {
      // Pas de paramètre fourni : on regarde la suite.
    }

    // 2) Sinon, le nom déjà saisi et mémorisé lors d'un lancement précédent.
    name ??= prefs.getString(kWatchedNamePrefsKey);

    if (name != null && name.trim().isNotEmpty) {
      if (mounted) setState(() => _watchedName = name!.trim());
      // Mémorise aussi le nom reçu par Intent, pour les prochains
      // lancements manuels de l'app.
      await prefs.setString(kWatchedNamePrefsKey, name.trim());

      // Seulement maintenant, une éventuelle alerte NexSIS en attente peut
      // être traitée : le nom à rechercher est désormais connu.
      try {
        final pending = await intentChannel
            .invokeMethod<bool>('getPendingNexsisNotification') ?? false;
        if (pending) {
          await _handleNexsisNotification();
        }
      } on PlatformException {
        // Aucun événement NexSIS en attente.
      }
      return;
    }

    // 3) Premier lancement sans aucun nom connu : on demande directement,
    // au lieu d'utiliser un nom codé en dur (pratique pour partager l'app
    // telle quelle à des collègues).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _showWatchedNameDialog(isFirstLaunch: true);
    });
  }

  Future<void> _setWatchedName(String name, SharedPreferences prefs) async {
    if (!mounted) return;
    setState(() {
      _watchedName = name;
      _notifiedInterventionIds.clear();
    });
    await prefs.setString(kWatchedNamePrefsKey, name);
  }

  Future<void> _showWatchedNameDialog({bool isFirstLaunch = false}) async {
    final controller = TextEditingController(text: _watchedName);
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: !isFirstLaunch,
      builder: (context) => PopScope(
        canPop: !isFirstLaunch,
        child: AlertDialog(
          title: Text(
            isFirstLaunch ? 'Bienvenue sur Orbe Viewer' : 'Nom à surveiller',
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (isFirstLaunch)
                const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text(
                    "Quel nom l'app doit-elle surveiller sur les engins "
                    "en attente ? Tu pourras le changer plus tard via le "
                    "bouton \"Cible\" en haut de l'écran.",
                  ),
                ),
              TextField(
                controller: controller,
                autofocus: true,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  hintText: 'Ex: Prénom NOM',
                ),
                onSubmitted: (value) => Navigator.of(context).pop(value),
              ),
            ],
          ),
          actions: [
            if (!isFirstLaunch)
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Annuler'),
              ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(controller.text),
              child: const Text('Valider'),
            ),
          ],
        ),
      ),
    );
    if (result != null && result.trim().isNotEmpty && mounted) {
      final prefs = await SharedPreferences.getInstance();
      await _setWatchedName(result.trim(), prefs);
    } else if (isFirstLaunch && mounted) {
      // Aucun nom saisi : on redemande, un nom est nécessaire pour que
      // l'app serve à quelque chose.
      _showWatchedNameDialog(isFirstLaunch: true);
    }
  }

  Future<void> _handleNexsisNotification() async {
    // NexSIS ne nous donne pas directement le véhicule : son rôle est
    // uniquement de signaler qu'une nouvelle intervention est arrivée.
    // On ramène Orbe au premier plan puis on cherche immédiatement dans
    // sa liste "Engin en attente".
    _pendingNexsisScan = true;
    if (!_pageReady || _watchedName.trim().isEmpty) return;
    _pendingNexsisScan = false;
    await _runNexsisTriggeredScan();
  }

  Future<void> _runNexsisTriggeredScan() async {
    if (_nexsisScanRunning || !_pageReady || _watchedName.trim().isEmpty) {
      return;
    }
    _nexsisScanRunning = true;
    try {
      // Premier passage immédiat : si Orbe a déjà reçu la nouvelle carte,
      // aucune actualisation lourde n'est nécessaire.
      var found = await _checkForWatchedCrewName();
      if (found) return;

      // La page Orbe peut avoir besoin de quelques centaines de ms pour
      // intégrer la nouvelle intervention.
      await Future.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;
      found = await _checkForWatchedCrewName();
      if (found) return;

      await Future.delayed(const Duration(milliseconds: 1000));
      if (!mounted) return;
      found = await _checkForWatchedCrewName();
      if (found) return;

      // Si elle n'est toujours pas visible, on force un rafraîchissement
      // complet d'Orbe. onPageFinished relancera alors automatiquement le
      // scan dès que la page sera de nouveau prête.
      if (mounted) {
        _pendingNexsisScan = true;
        await _controller.reload();
      }
    } finally {
      _nexsisScanRunning = false;
    }
  }

  Future<void> _openNexsisListenerSettings() async {
    try {
      await intentChannel.invokeMethod('openNotificationListenerSettings');
    } on PlatformException {
      // Les réglages Android restent accessibles manuellement si nécessaire.
    }
  }

  Future<void> _initNotifications() async {
    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    await _notificationsPlugin.initialize(
      const InitializationSettings(android: androidSettings),
    );
    final androidPlugin = _notificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    _notificationsReady = true;
  }

  // Nettoie une chaîne JSON renvoyée par runJavaScriptReturningResult :
  // sur Android elle est entourée de guillemets et les guillemets internes
  // sont échappés.
  String _cleanJsResult(Object result) {
    String display = result.toString();
    if (display.startsWith('"') && display.endsWith('"')) {
      display = display.substring(1, display.length - 1);
    }
    return display.replaceAll(r'\"', '"');
  }

  // Recherche dans la page une carte "Engin en attente" dont l'équipage
  // contient kWatchedCrewName, et en extrait l'identifiant d'intervention
  // ainsi que le code véhicule (lettres entre le numéro et le "-").
  Future<List<Map<String, dynamic>>> _scanForWatchedCrewName() async {
    final watchedNameUpper = _watchedName.toUpperCase();
    final rawResult = await _controller.runJavaScriptReturningResult('''
      JSON.stringify((function() {
        // Accepte deux formats de code véhicule :
        // - avec tiret : VSAV-00285
        // - avec underscores, sans tiret : VL_CDG_19_2
        var idRegex = /\\d{8}_\\d{4}\\s*([A-Z]+(?:_[A-Z]+)*)(?=-|_\\d|\$|\\s)/;
        var badgeRegex = /ENGIN\\s+EN\\s+ATTENTE/i;
        var watched = '$watchedNameUpper';
        var results = [];
        var seenIds = {};

        function extract(t, cleanT) {
          var idMatch = cleanT.match(idRegex);
          if (!idMatch) return;
          var interventionId = idMatch[0].replace(/\\s+/g, '');
          if (seenIds[interventionId]) return;
          seenIds[interventionId] = true;
          var motifMatch = t.match(/DEPUIS\\s+\\d+\\s*MIN\\s*\\d*\\s*([\\s\\S]*?)(?:\\n?\\s*(?:SGT|ADJ|CPL|SAP|LTN|CDT|CCH|CNE|MJR|CCL)\\b|\$)/i);
          var motif = motifMatch ? motifMatch[1].replace(/\\s+/g, ' ').trim() : '';
          // Rôle occupé par la personne recherchée sur cet engin (COND, EQ,
          // CA, CE, CU...) : on cherche le prochain code de rôle CONNU après
          // son nom (et non le simple token suivant), pour ne pas confondre
          // avec le nom de famille si "watched" ne matche qu'un prénom.
          var role = '';
          var nameIdx = t.toUpperCase().indexOf(watched);
          if (nameIdx !== -1) {
            var after = t.substring(nameIdx + watched.length, nameIdx + watched.length + 80);
            var roleMatch = after.match(/\\b(COND|EQ|CA|CE|CU)\\b/);
            if (roleMatch) role = roleMatch[1];
          }
          results.push({
            interventionId: interventionId,
            vehicle: idMatch[1],
            motif: motif,
            role: role
          });
        }

        // Stratégie principale : cibler directement le conteneur de chaque
        // carte engin via sa classe CSS (identifiée via l'inspecteur Chrome),
        // ce qui isole parfaitement chaque engin, même quand plusieurs
        // engins partagent la même intervention.
        var cardEls = document.querySelectorAll('div[class*="br-20"][class*="bg-white"]');

        if (cardEls.length > 0) {
          for (var i = 0; i < cardEls.length; i++) {
            var el = cardEls[i];
            var t = el.innerText;
            if (!t) continue;
            var upper = t.toUpperCase();
            var cleanT = t.replace(/[\\u200B\\u200C\\u200D\\uFEFF]/g, '');
            // Rejette les conteneurs qui englobent plusieurs cartes (classes
            // utilitaires parfois réutilisées à un niveau plus large) : une
            // vraie carte ne contient le badge qu'une seule fois.
            var badgeCount = (t.match(new RegExp(badgeRegex.source, 'gi')) || []).length;
            if (badgeCount !== 1) continue;
            if (badgeRegex.test(t) && upper.indexOf(watched) !== -1) {
              extract(t, cleanT);
            }
          }
        } else {
          // Repli si la classe CSS a changé : ancienne méthode par
          // recherche du plus petit conteneur textuel valide.
          var all = document.querySelectorAll('body *');
          var matches = [];
          for (var j = 0; j < all.length; j++) {
            var el2 = all[j];
            var t2 = el2.innerText;
            if (!t2 || t2.length > 1500) continue;
            var upper2 = t2.toUpperCase();
            var cleanT2 = t2.replace(/[\\u200B\\u200C\\u200D\\uFEFF]/g, '');
            if (upper2.indexOf('PLANNING') !== -1) continue;
            var badgeCount2 = (t2.match(new RegExp(badgeRegex.source, 'gi')) || []).length;
            if (badgeCount2 !== 1) continue;
            if (badgeRegex.test(t2) &&
                upper2.indexOf(watched) !== -1 &&
                idRegex.test(cleanT2)) {
              matches.push({ el: el2, text: cleanT2, raw: t2 });
            }
          }
          matches.sort(function(a, b) { return a.text.length - b.text.length; });
          var accepted = [];
          for (var k = 0; k < matches.length; k++) {
            var m = matches[k];
            var isNested = false;
            for (var n = 0; n < accepted.length; n++) {
              if (accepted[n].contains(m.el)) { isNested = true; break; }
            }
            if (isNested) continue;
            accepted.push(m.el);
            extract(m.raw, m.text);
          }
        }

        return results;
      })());
    ''');

    final cleaned = _cleanJsResult(rawResult);
    if (cleaned.isEmpty || cleaned == 'null') return [];
    final List<dynamic> items = jsonDecode(cleaned) as List<dynamic>;
    return items.cast<Map<String, dynamic>>();
  }

  // Diagnostic détaillé : inspecte précisément ce qui se passe côté
  // sélecteur CSS pour la carte contenant le nom, pour savoir pourquoi le
  // scan principal échoue sur ce cas précis.
  Future<Map<String, dynamic>> _diagnoseScan() async {
    final watchedNameUpper = _watchedName.toUpperCase();
    final rawResult = await _controller.runJavaScriptReturningResult('''
      JSON.stringify((function() {
        var idRegex = /\\d{8}_\\d{4}\\s*[A-Z]+(?:_[A-Z]+)*(?=-|_\\d|\$|\\s)/;
        var badgeRegex = /ENGIN\\s+EN\\s+ATTENTE/i;
        var watched = '$watchedNameUpper';
        var bodyText = document.body.innerText || '';

        var cardEls = document.querySelectorAll('div[class*="br-20"][class*="bg-white"]');
        var matchingCards = [];
        for (var i = 0; i < cardEls.length; i++) {
          var t = cardEls[i].innerText || '';
          if (t.toUpperCase().indexOf(watched) !== -1) {
            var badgeCount = (t.match(new RegExp(badgeRegex.source, 'gi')) || []).length;
            var cleanT = t.replace(/[\\u200B\\u200C\\u200D\\uFEFF]/g, '');
            matchingCards.push({
              textLength: t.length,
              badgeCount: badgeCount,
              hasBadge: badgeRegex.test(t),
              idFound: idRegex.test(cleanT),
              excerpt: t.substring(0, 300)
            });
          }
        }

        var nameIdx = bodyText.toUpperCase().indexOf(watched);
        var sampleStart = Math.max(0, nameIdx - 120);
        var sample = nameIdx !== -1 ? bodyText.substring(sampleStart, sampleStart + 250) : '';

        return {
          cardElsSelectorCount: cardEls.length,
          matchingCardsCount: matchingCards.length,
          matchingCards: matchingCards,
          badgeOccurrencesOnPage: (bodyText.match(new RegExp(badgeRegex.source, 'gi')) || []).length,
          nameOccurrencesOnPage: (bodyText.toUpperCase().match(new RegExp(watched, 'g')) || []).length,
          sample: sample
        };
      })());
    ''');
    final cleaned = _cleanJsResult(rawResult);
    if (cleaned.isEmpty || cleaned == 'null') return {};
    return jsonDecode(cleaned) as Map<String, dynamic>;
  }

  Future<bool> _checkForWatchedCrewName() async {
    if (_ticketModeActive) return false;
    if (_watchedName.trim().isEmpty) return false;
    // Au tout premier scan après un lancement à froid, l'init des
    // notifications peut être encore en cours : on patiente un peu au lieu
    // d'abandonner silencieusement.
    var waited = 0;
    while (!_notificationsReady && waited < 3000) {
      await Future.delayed(const Duration(milliseconds: 200));
      waited += 200;
    }
    if (!_notificationsReady) return false;
    try {
      var items = await _scanForWatchedCrewName();

      // Si un motif ressort vide, la page était peut-être encore en train
      // de se mettre à jour au moment du scan : on retente une fois après
      // un court délai avant d'accepter "Motif inconnu".
      final hasEmptyMotif = items.any((m) {
        final motif = m['motif'] as String?;
        return motif == null || motif.isEmpty;
      });
      if (hasEmptyMotif) {
        await Future.delayed(const Duration(milliseconds: 1500));
        final retryItems = await _scanForWatchedCrewName();
        final retryById = {
          for (final m in retryItems) m['interventionId'] as String?: m,
        };
        items = items.map((m) {
          final motif = m['motif'] as String?;
          if (motif == null || motif.isEmpty) {
            final retry = retryById[m['interventionId']];
            if (retry != null) return retry;
          }
          return m;
        }).toList();
      }

      var notifiedAny = false;
      for (final map in items) {
        final interventionId = map['interventionId'] as String?;
        final vehicle = map['vehicle'] as String?;
        final motif = map['motif'] as String?;
        final role = map['role'] as String?;
        if (interventionId == null) {
          continue;
        }
        _lastNotifiedInterventionId = interventionId;
        if (_notifiedInterventionIds.contains(interventionId)) {
          continue;
        }
        final vehicleLabel = vehicle ?? '?';
        final roleLabel = (role != null && role.isNotEmpty) ? ' ($role)' : '';
        final motifLabel =
            (motif != null && motif.isNotEmpty) ? motif : 'Motif inconnu';
        try {
          await _notificationsPlugin.show(
            interventionId.hashCode,
            'Orbe — Engin en attente',
            '$vehicleLabel$roleLabel — $motifLabel — $interventionId',
            NotificationDetails(
              android: AndroidNotificationDetails(
                'orbe_watch_channel',
                'Orbe — Engins en attente',
                channelDescription:
                    'Alerte quand $_watchedName apparaît sur un engin en attente',
                importance: Importance.max,
                priority: Priority.high,
              ),
            ),
          );
          // On mémorise l'intervention seulement après une notification
          // effectivement envoyée. Sinon une erreur Android silencieuse
          // pourrait rendre l'intervention définitivement muette.
          _notifiedInterventionIds.add(interventionId);
          notifiedAny = true;
        } catch (_) {
          // Ne pas bloquer les autres interventions si l'affichage d'une
          // notification échoue. Elle sera retentée au prochain scan.
        }
      }
      // true signifie qu'une intervention correspondant à la cible a été
      // trouvée (même si elle avait déjà été notifiée).
      if (items.isNotEmpty) return true;
      return notifiedAny;
    } catch (_) {
      // Erreur de scan silencieuse : on retentera au prochain cycle.
      return false;
    }
  }

  // Scan manuel immédiat + affichage du résultat brut, pour diagnostiquer
  // sans attendre le prochain cycle de 25 secondes.
  Future<void> _showManualScanResult() async {
    if (_watchedName.trim().isEmpty) {
      await _showWatchedNameDialog();
      return;
    }
    try {
      final items = await _scanForWatchedCrewName();
      if (!mounted) return;

      String content;
      if (items.isNotEmpty) {
        content = items
            .map((e) =>
                '${e['interventionId']} → ${e['vehicle']} (${e['role']})\nMotif : ${e['motif']}')
            .join('\n\n');
      } else {
        final diag = await _diagnoseScan();
        if (!mounted) return;
        final matchingCards = (diag['matchingCards'] as List?) ?? [];
        final cardsDetail = matchingCards.isEmpty
            ? '(aucune carte du sélecteur CSS ne contient ce nom)'
            : matchingCards.asMap().entries.map((entry) {
                final c = entry.value as Map<String, dynamic>;
                return 'Carte ${entry.key + 1} : longueur=${c['textLength']}, '
                    'badges=${c['badgeCount']}, idTrouvé=${c['idFound']}\n'
                    'Extrait : ${c['excerpt']}';
              }).join('\n\n');
        content = 'Aucune carte "Engin en attente" trouvée avec ce nom.\n\n'
            '— Diagnostic —\n'
            'Cartes trouvées via le sélecteur CSS : ${diag['cardElsSelectorCount']}\n'
            'Dont contenant "$_watchedName" : ${diag['matchingCardsCount']}\n'
            'Badges sur la page entière : ${diag['badgeOccurrencesOnPage']}\n'
            'Occurrences du nom sur la page : ${diag['nameOccurrencesOnPage']}\n\n'
            '$cardsDetail';
      }

      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Scan pour "$_watchedName"'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(child: Text(content)),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Erreur de scan'),
          content: Text(e.toString()),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    }
  }

  // Le menu déroulant "Engins en attente / Sorties en cours" est un <select>
  // HTML classique. On force la sélection sur "Sorties en cours" au
  // chargement, en déclenchant les événements que le framework du site
  // écoute pour mettre à jour l'affichage.
  Future<void> _selectSortiesEnCoursTab() async {
    await _controller.runJavaScript('''
      (function() {
        var selects = document.querySelectorAll('select');
        for (var i = 0; i < selects.length; i++) {
          var s = selects[i];
          for (var j = 0; j < s.options.length; j++) {
            if (s.options[j].text.trim() === 'Sorties en cours') {
              if (s.selectedIndex !== j) {
                s.selectedIndex = j;
                s.dispatchEvent(new Event('change', { bubbles: true }));
                s.dispatchEvent(new Event('input', { bubbles: true }));
              }
              return;
            }
          }
        }
      })();
    ''');
  }

  // Le site affiche un paragraphe explicatif ("Cette page propose un suivi
  // technique...") qui prend beaucoup de place utile à l'écran. On le
  // masque simplement, sans toucher au reste de la page.
  Future<void> _hideDescriptionText() async {
    await _controller.runJavaScript('''
      (function() {
        var marker = 'Cette page propose un suivi technique';
        var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
        var node;
        while (node = walker.nextNode()) {
          if (node.nodeValue && node.nodeValue.indexOf(marker) !== -1) {
            var el = node.parentElement;
            if (el) el.style.display = 'none';
            break;
          }
        }
      })();
    ''');
  }

  Future<void> _showDebugInfo() async {
    final result = await _controller.runJavaScriptReturningResult('''
      JSON.stringify({
        devicePixelRatio: window.devicePixelRatio,
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight,
        screenWidth: screen.width,
        screenHeight: screen.height,
        bodyClientWidth: document.body.clientWidth,
        fontsReady: document.fonts ? document.fonts.status : 'n/a',
        fonts: document.fonts ? Array.from(document.fonts).map(function(f) {
          return f.family + ' | ' + f.status;
        }) : []
      })
    ''');

    if (!mounted) return;

    // Le résultat est une chaîne JSON échappée (entourée de guillemets) selon
    // la plateforme ; on nettoie pour un affichage lisible.
    String display = result.toString();
    if (display.startsWith('"') && display.endsWith('"')) {
      display = display.substring(1, display.length - 1);
    }
    display = display.replaceAll(r'\"', '"');

    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Infos viewport'),
        content: SelectableText(display),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fermer'),
          ),
        ],
      ),
    );
  }

  Future<void> _applyZoom(double percent) async {
    if (!mounted) return;
    setState(() => _zoomPercent = percent);
    await _controller.runJavaScript(
      "document.body.style.zoom = '${percent.round()}%';",
    );
  }

  Future<void> _loadLastCenter() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(kLastCenterPrefsKey);
    if (saved != null && saved.trim().isNotEmpty && mounted) {
      setState(() => _lastCenterName = saved.trim());
    }
  }

  Future<String?> _askCenterName() async {
    final controller = TextEditingController(text: _lastCenterName);
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ticket de départ — quel centre ?'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(hintText: 'Ex: MOIRANS'),
          onSubmitted: (value) => Navigator.of(context).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(controller.text),
            child: const Text('Chercher'),
          ),
        ],
      ),
    );
  }

  // Cherche l'infobulle Leaflet correspondant au nom du centre (elle porte
  // le texte du nom), retrouve le marqueur qui la référence via
  // aria-describedby, puis clique dessus pour ouvrir le panneau du centre.
  Future<bool> _clickCenterMarker(String centerName) async {
    final centerUpper = centerName.trim().toUpperCase();
    final result = await _controller.runJavaScriptReturningResult('''
      (function() {
        var tooltips = document.querySelectorAll('.leaflet-tooltip');
        var target = null;
        for (var i = 0; i < tooltips.length; i++) {
          var t = (tooltips[i].textContent || '').trim().toUpperCase();
          if (t === '$centerUpper' || t.indexOf('$centerUpper') !== -1) {
            target = tooltips[i];
            break;
          }
        }
        if (!target || !target.id) return false;
        var marker = document.querySelector('[aria-describedby="' + target.id + '"]');
        if (!marker) return false;
        marker.click();
        return true;
      })();
    ''');
    return result.toString() == 'true';
  }

  // Récupère le texte complet du ticket : on prend le plus petit conteneur
  // qui contient à la fois "N° d'intervention" et "Train de départ", ce qui
  // capture le numéro, le motif, les horaires et l'engin engagé d'un coup,
  // quelle que soit la structure exacte imbriquée.
  /// Récupère directement les opérations depuis l'API Orbe. Le fetch est
  /// exécuté dans la WebView afin de réutiliser automatiquement la session
  /// Orbe déjà authentifiée.
  Future<List<Map<String, dynamic>>> _fetchOperationsFromApi() async {
    // runJavaScriptReturningResult n'attend pas une Promise. On utilise donc
    // un XHR synchrone dans la WebView pour conserver la session Orbe.
    final rawResult = await _controller.runJavaScriptReturningResult(r'''      (function() {
        try {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', '/api/me/operations', false);
          xhr.withCredentials = true;
          xhr.setRequestHeader('Accept', 'application/json');
          xhr.send(null);
          var text = xhr.responseText || '';
          var data = null;
          try { data = JSON.parse(text); } catch (_) {}
          return JSON.stringify({
            ok: xhr.status >= 200 && xhr.status < 300,
            status: xhr.status,
            statusText: xhr.statusText || '',
            data: data,
            error: xhr.status === 0 ? 'Connexion impossible ou requête bloquée' : ''
          });
        } catch (e) {
          return JSON.stringify({ ok: false, status: -1, error: String(e) });
        }
      })();
    ''');

    final cleaned = _cleanJsResult(rawResult);
    if (cleaned.isEmpty || cleaned == 'null') {
      throw Exception('API /api/me/operations : réponse vide');
    }
    final decoded = jsonDecode(cleaned) as Map<String, dynamic>;
    if (decoded['ok'] != true) {
      final status = decoded['status'];
      final detail = (decoded['error'] ?? decoded['statusText'] ?? '').toString();
      throw Exception('API /api/me/operations : HTTP $status${detail.isNotEmpty ? ' ($detail)' : ''}');
    }
    final data = decoded['data'];
    if (data is! List) return [];
    return data.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  String _formatDateTime(String value) {
    try {
      final dt = DateTime.parse(value).toLocal();
      String two(int n) => n.toString().padLeft(2, '0');
      return '${two(dt.day)}/${two(dt.month)} ${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
    } catch (_) {
      return value;
    }
  }

  String _formatOperationTicket(Map<String, dynamic> operation,
      {String? centerName, bool highlight = false}) {
    final vehicles = (operation['vehicles'] as List?)
            ?.whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList() ??
        [];
    final centerUpper = centerName?.trim().toUpperCase();
    final centerVehicles = centerUpper == null || centerUpper.isEmpty
        ? vehicles
        : vehicles.where((v) {
            return (v['name'] ?? '').toString().toUpperCase().contains(centerUpper);
          }).toList();

    final lines = <String>[];
    final num = (operation['num'] ?? operation['id'] ?? '').toString();
    final title = (operation['title'] ?? '').toString();
    final city = (operation['city'] ?? '').toString();
    final street = (operation['street1'] ?? '').toString();
    final body = (operation['body'] ?? '').toString();

    lines.add(highlight ? '🎯 TICKET DE DÉPART' : '📋 TICKET');
    lines.add('**Intervention : $num**');
    if (title.isNotEmpty) lines.add('Motif : $title');
    if (street.isNotEmpty || city.isNotEmpty) {
      lines.add('Lieu : ${[street, city].where((e) => e.isNotEmpty).join(', ')}');
    }
    if (body.isNotEmpty) lines.add('Détail : $body');

    final additionalContent = (operation['additionalContent'] ?? '').toString();
    if (additionalContent.trim().isNotEmpty) {
      lines.add('');
      lines.add('ℹ️ INFORMATIONS INTERVENTION');
      // L'API peut renvoyer les retours à la ligne sous forme de texte littéral \n      // (\\n), voire sous forme de balises HTML <br>. On normalise tout
      // avant l'affichage pour conserver une ligne par information.
      final formattedAdditionalContent = additionalContent
          .replaceAll('\u00A0', ' ')
          .replaceAll(r'\n', '\n')
          .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
      for (final rawLine in formattedAdditionalContent.split('\n')) {
        final line = rawLine.trim();
        if (line.isNotEmpty) lines.add(line);
      }
    }

    final messages = (operation['messages'] as List?)
            ?.whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList() ??
        [];
    if (messages.isNotEmpty) {
      lines.add('');
      lines.add('💬 MESSAGES');
      for (final message in messages) {
        final datetime = (message['datetime'] ?? '').toString();
        final from = (message['from'] ?? '').toString();
        var text = (message['body'] ?? '').toString();
        text = text
            .replaceAll('&nbsp;', ' ')
            .replaceAll('&amp;', '&')
            .replaceAll('&lt;', '<')
            .replaceAll('&gt;', '>')
            .replaceAll(RegExp(r'<br\\s*/?>', caseSensitive: false), '\\n')
            .replaceAll(RegExp(r'<[^>]*>'), '')
            .replaceAll(r'\\n', '\\n')
            .replaceAll('\\r\\n', '\\n');
        if (datetime.isNotEmpty || from.isNotEmpty) {
          lines.add('${datetime.isNotEmpty ? _formatDateTime(datetime) : ''}${from.isNotEmpty ? ' — $from' : ''}');
        }
        if (text.isNotEmpty) {
          for (final line in text.split('\\n')) {
            final cleanLine = line.trim();
            if (cleanLine.isNotEmpty) lines.add(cleanLine);
          }
        }
      }
    }

    if (centerVehicles.isNotEmpty) {
      lines.add('');
      lines.add('Engins de ${centerUpper ?? ''}:'.trim());
      for (final vehicle in centerVehicles) {
        final name = (vehicle['name'] ?? vehicle['cod'] ?? '?').toString();
        final status = (vehicle['status'] ?? '').toString();
        final departure = (vehicle['departureTime'] ?? '').toString();
        lines.add('🚒 $name');
        if (status.isNotEmpty) lines.add('   Statut : $status');
        if (departure.isNotEmpty) lines.add('   Départ : ${_formatDateTime(departure)}');
        final firefighters = (vehicle['firefighters'] as List?)
                ?.whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList() ??
            [];

        // Ordre d'affichage des postes dans le ticket :
        // CA -> COND -> CE -> EQ.
        // Le tri est stable : deux personnes ayant le même poste
        // conservent l'ordre fourni par Orbe.
        const roleOrder = <String, int>{
          'CA': 0,
          'COND': 1,
          'CE': 2,
          'EQ': 3,
        };
        firefighters.sort((a, b) {
          final roleA = (a['operationalRole'] ?? '').toString().trim().toUpperCase();
          final roleB = (b['operationalRole'] ?? '').toString().trim().toUpperCase();
          final orderA = roleOrder[roleA] ?? 99;
          final orderB = roleOrder[roleB] ?? 99;
          return orderA.compareTo(orderB);
        });

        for (final firefighter in firefighters) {
          final name = (firefighter['name'] ?? '').toString();
          final role = (firefighter['operationalRole'] ?? '').toString().trim();
          if (name.isNotEmpty) {
            lines.add('   • ${role.isNotEmpty ? '$role - ' : ''}$name');
          }
        }
      }
    }
    return lines.join('\n');
  }

  String _ticketTabLabel(Map<String, dynamic> operation) {
    final num = (operation['num'] ?? operation['id'] ?? '').toString().trim();
    if (num.isEmpty) return '?';

    // Exemple : 20260911_0134 -> 134.
    final match = RegExp(r'(\d{1,})$').firstMatch(num);
    if (match != null) {
      final digits = match.group(1)!;
      return digits.length <= 3 ? digits : digits.substring(digits.length - 3);
    }

    // Repli si l'identifiant ne se termine pas par des chiffres.
    final compact = num.replaceAll(RegExp(r'\D'), '');
    if (compact.isNotEmpty) {
      return compact.length <= 3 ? compact : compact.substring(compact.length - 3);
    }
    return num.length <= 3 ? num : num.substring(num.length - 3);
  }

  bool _operationContainsWatchedName(
    Map<String, dynamic> operation,
    String watchedName,
  ) {
    final wanted = watchedName.trim().toUpperCase();
    if (wanted.isEmpty) return false;

    final vehicles = (operation['vehicles'] as List?)
            ?.whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList() ??
        [];

    for (final vehicle in vehicles) {
      final vehicleName = (vehicle['name'] ?? '').toString().toUpperCase();
      if (vehicleName.contains(wanted)) return true;

      final firefighters = (vehicle['firefighters'] as List?)
              ?.whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList() ??
          [];

      for (final firefighter in firefighters) {
        final firefighterName =
            (firefighter['name'] ?? '').toString().toUpperCase();
        if (firefighterName.contains(wanted)) return true;
      }
    }
    return false;
  }


  String _cleanDisplayText(String value) {
    return value
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .trim();
  }

  String _formatInterventionSummary(Map<String, dynamic> operation) {
    final lines = <String>[];
    final num = (operation['num'] ?? operation['id'] ?? '').toString().trim();
    final motif = _cleanDisplayText((operation['title'] ?? '').toString());
    final city = _cleanDisplayText((operation['city'] ?? '').toString());
    final street = _cleanDisplayText((operation['street1'] ?? '').toString());

    lines.add(num.isEmpty ? 'INTERVENTION' : 'INTERVENTION $num');
    if (motif.isNotEmpty) lines.add('Motif : $motif');
    if (street.isNotEmpty || city.isNotEmpty) {
      lines.add('Lieu : ${[street, city].where((e) => e.isNotEmpty).join(', ')}');
    }

    final vehicles = (operation['vehicles'] as List?)
            ?.whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList() ??
        [];

    if (vehicles.isNotEmpty) {
      lines.add('');
      lines.add('🚒 VÉHICULES ET PERSONNELS');

      // On affiche maintenant chaque équipage directement sous son véhicule.
      // Cela permet d'identifier immédiatement quel personnel est affecté
      // à quel engin lorsqu'une intervention comporte plusieurs véhicules.
      const roleOrder = <String, int>{
        'CA': 0,
        'COND': 1,
        'CE': 2,
        'EQ': 3,
      };

      for (final vehicle in vehicles) {
        final name = _cleanDisplayText(
          (vehicle['name'] ?? vehicle['cod'] ?? '?').toString(),
        );
        if (name.isEmpty) continue;

        lines.add('');
        lines.add('🚒 $name');

        final center = _cleanDisplayText(
          (vehicle['center'] ?? vehicle['cis'] ?? vehicle['station'] ??
                  vehicle['centerName'] ?? vehicle['cisName'] ?? '')
              .toString(),
        );
        if (center.isNotEmpty) {
          lines.add('   Centre : $center');
        }

        final firefighters = (vehicle['firefighters'] as List?)
                ?.whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList() ??
            [];

        firefighters.sort((a, b) {
          final roleA = (a['operationalRole'] ?? '').toString().trim().toUpperCase();
          final roleB = (b['operationalRole'] ?? '').toString().trim().toUpperCase();
          return (roleOrder[roleA] ?? 99).compareTo(roleOrder[roleB] ?? 99);
        });

        for (final firefighter in firefighters) {
          final name = _cleanDisplayText((firefighter['name'] ?? '').toString());
          final role = _cleanDisplayText((firefighter['operationalRole'] ?? '').toString());
          if (name.isNotEmpty) {
            lines.add('   • ${role.isNotEmpty ? '$role - ' : ''}$name');
          }
        }
      }
    }

    final messages = (operation['messages'] as List?)
            ?.whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList() ??
        [];
    if (messages.isNotEmpty) {
      lines.add('');
      lines.add('💬 MESSAGES');
      for (final message in messages) {
        final datetime = (message['datetime'] ?? '').toString().trim();
        final from = _cleanDisplayText((message['from'] ?? '').toString());
        final text = _cleanDisplayText((message['body'] ?? '').toString());
        if (datetime.isNotEmpty || from.isNotEmpty) {
          lines.add('${datetime.isNotEmpty ? _formatDateTime(datetime) : ''}${from.isNotEmpty ? ' — $from' : ''}');
        }
        if (text.isNotEmpty) lines.add(text);
      }
    }
    return lines.join('\n');
  }

  Future<void> _showInterventions() async {
    setState(() => _ticketModeActive = true);
    List<Map<String, dynamic>> operations;
    try {
      operations = await _fetchOperationsFromApi();
    } catch (e) {
      if (mounted) setState(() => _ticketModeActive = false);
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Interventions'),
          content: SelectableText('Erreur pendant la récupération des interventions : $e'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Fermer')),
          ],
        ),
      );
      return;
    }
    if (mounted) setState(() => _ticketModeActive = false);
    await _controller.loadRequest(Uri.parse(kOrbeUrl));
    if (!mounted) return;

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        titlePadding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
        contentPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        title: Row(
          children: [
            Expanded(
              child: Text('Interventions (${operations.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            IconButton(
              tooltip: 'Fermer',
              onPressed: () => Navigator.of(dialogContext).pop(),
              icon: const Icon(Icons.close),
            ),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: MediaQuery.of(dialogContext).size.height * 0.76,
          child: operations.isEmpty
              ? const Center(child: Text('Aucune intervention trouvée.'))
              : ListView.separated(
                  itemCount: operations.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final operation = operations[index];
                    final num = (operation['num'] ?? operation['id'] ?? '').toString();
                    final isMine = (_lastNotifiedInterventionId?.trim().isNotEmpty ?? false) &&
                        (num == _lastNotifiedInterventionId!.trim());
                    return Card(
                      elevation: isMine ? 5 : 1,
                      color: isMine ? const Color(0xFFE8F5E9) : null,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ExpansionTile(
                        initiallyExpanded: isMine,
                        leading: CircleAvatar(
                          child: Text(_ticketTabLabel(operation)),
                        ),
                        title: Text(
                          num.isEmpty ? 'Intervention' : num,
                          style: TextStyle(fontWeight: isMine ? FontWeight.bold : FontWeight.w600),
                        ),
                        subtitle: Text(
                          _cleanDisplayText((operation['title'] ?? '').toString()).isEmpty
                              ? 'Motif non renseigné'
                              : _cleanDisplayText((operation['title'] ?? '').toString()),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: SelectableText(_formatInterventionSummary(operation)),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }

  Future<void> _showCenterTicket() async {
    final centerName = await _askCenterName();
    if (centerName == null || centerName.trim().isEmpty) return;

    final prefs = await SharedPreferences.getInstance();
    final cleanCenter = centerName.trim();
    setState(() => _lastCenterName = cleanCenter);
    await prefs.setString(kLastCenterPrefsKey, cleanCenter);
    setState(() => _ticketModeActive = true);

    List<Map<String, dynamic>> centerOperations = [];
    Map<String, dynamic>? myOperation;

    try {
      final operations = await _fetchOperationsFromApi();
      final centerUpper = cleanCenter.toUpperCase();

      centerOperations = operations.where((operation) {
        final vehicles = (operation['vehicles'] as List?) ?? [];
        return vehicles.whereType<Map>().any((vehicle) {
          final name = (vehicle['name'] ?? '').toString().toUpperCase();
          return name.contains(centerUpper);
        });
      }).toList();

      // 1) Priorité au numéro récupéré lors du scan / de la notification Orbe.
      final wantedId = _lastNotifiedInterventionId?.trim();
      if (wantedId != null && wantedId.isNotEmpty) {
        for (final operation in centerOperations) {
          final num = (operation['num'] ?? '').toString().trim();
          final id = (operation['id'] ?? '').toString().trim();
          if (num == wantedId || id == wantedId) {
            myOperation = operation;
            break;
          }
        }
      }

      // 2) Si aucun numéro n'a été récupéré, recherche directe du nom surveillé
      // (ex. CALABRO) dans l'équipage de chaque opération.
      if (myOperation == null && _watchedName.trim().isNotEmpty) {
        for (final operation in centerOperations) {
          if (_operationContainsWatchedName(operation, _watchedName)) {
            myOperation = operation;
            break;
          }
        }
      }

      // Met mon ticket en premier : cela permet de le voir immédiatement
      // dans le premier onglet tout en conservant tous les autres tickets.
      if (myOperation != null) {
        centerOperations = [
          myOperation!,
          ...centerOperations.where((operation) => !identical(operation, myOperation)),
        ];
      }
    } catch (e) {
      if (mounted) setState(() => _ticketModeActive = false);
      await _controller.loadRequest(Uri.parse(kOrbeUrl));
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Ticket — $cleanCenter'),
          content: SelectableText(
            'Erreur pendant la récupération des tickets : $e',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
      return;
    }

    if (mounted) setState(() => _ticketModeActive = false);
    await _controller.loadRequest(Uri.parse(kOrbeUrl));

    if (!mounted) return;

    if (centerOperations.isEmpty) {
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Ticket — $cleanCenter'),
          content: const Text('Aucun ticket actif trouvé pour ce centre.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
      return;
    }

    // Un onglet = un ticket.
    // L'onglet de mon intervention est volontairement beaucoup plus visible.
    final initialIndex = myOperation == null ? 0 : 0;

    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return DefaultTabController(
          length: centerOperations.length,
          initialIndex: initialIndex,
          child: AlertDialog(
            titlePadding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
            contentPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    'Tickets — $cleanCenter',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  tooltip: 'Fermer',
                  onPressed: () => Navigator.of(dialogContext).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            content: SizedBox(
              width: double.maxFinite,
              height: MediaQuery.of(dialogContext).size.height * 0.72,
              child: Column(
                children: [
                  SizedBox(
                    height: 52,
                    child: TabBar(
                      isScrollable: true,
                      tabAlignment: TabAlignment.start,
                      dividerHeight: 1,
                      tabs: [
                        for (var i = 0; i < centerOperations.length; i++)
                          _buildTicketTab(
                            centerOperations[i],
                            isMine: myOperation != null &&
                                identical(centerOperations[i], myOperation),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: TabBarView(
                      children: [
                        for (var i = 0; i < centerOperations.length; i++)
                          Container(
                            decoration: BoxDecoration(
                              color: myOperation != null &&
                                      identical(centerOperations[i], myOperation)
                                  ? const Color(0xFFE8F5E9)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.all(10),
                            child: SingleChildScrollView(
                              child: SelectableText(
                                _formatOperationTicket(
                                  centerOperations[i],
                                  centerName: cleanCenter,
                                  highlight: myOperation != null &&
                                      identical(centerOperations[i], myOperation),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTicketTab(
    Map<String, dynamic> operation, {
    required bool isMine,
  }) {
    final label = _ticketTabLabel(operation);
    final num = (operation['num'] ?? operation['id'] ?? '').toString();

    if (isMine) {
      return Tab(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: const Color(0xFF2E7D32),
            borderRadius: BorderRadius.circular(10),
            boxShadow: const [
              BoxShadow(
                blurRadius: 4,
                offset: Offset(0, 2),
                color: Color(0x55000000),
              ),
            ],
          ),
          child: Text(
            '★ $label',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      );
    }

    return Tab(
      child: Tooltip(
        message: num,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          child: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }

  Future<void> _showConsoleLogs() async {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logs console'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(
              _consoleLogs.isEmpty
                  ? '(aucun message)'
                  : _consoleLogs.join('\n\n'),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fermer'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        // Navigue dans l'historique interne de la WebView avant de quitter.
        if (await _controller.canGoBack()) {
          _controller.goBack();
        } else if (context.mounted) {
          Navigator.of(context).maybePop();
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              if (_progress < 1.0)
                LinearProgressIndicator(value: _progress, minHeight: 3),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: () => _showWatchedNameDialog(),
                      child: Text(
                        _watchedName.trim().isEmpty
                            ? 'Cible : définir'
                            : 'Cible: $_watchedName',
                      ),
                    ),
                    TextButton(
                      onPressed: _showManualScanResult,
                      child: const Text('Scanner'),
                    ),
                    TextButton(
                      onPressed: _openNexsisListenerSettings,
                      child: const Text('NexSIS'),
                    ),
                    TextButton(
                      onPressed: _showCenterTicket,
                      child: const Text('Ticket'),
                    ),
                    TextButton(
                      onPressed: _showInterventions,
                      child: const Text('Interventions'),
                    ),
                    TextButton(
                      onPressed: _showDebugInfo,
                      child: const Text('Debug'),
                    ),
                    TextButton(
                      onPressed: _showConsoleLogs,
                      child: const Text('Console'),
                    ),
                    IconButton(
                      tooltip: 'Réduire',
                      icon: const Icon(Icons.zoom_out),
                      onPressed: () =>
                          _applyZoom((_zoomPercent - 10).clamp(40, 150)),
                    ),
                    Text('${_zoomPercent.round()}%'),
                    IconButton(
                      tooltip: 'Agrandir',
                      icon: const Icon(Icons.zoom_in),
                      onPressed: () =>
                          _applyZoom((_zoomPercent + 10).clamp(40, 150)),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _hasError
                    ? _buildErrorView()
                    : WebViewWidget(controller: _controller),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
            const SizedBox(height: 12),
            const Text(
              "Impossible de charger la page Orbe.\n"
              "Vérifie ta connexion puis réessaie.",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _reload,
              icon: const Icon(Icons.refresh),
              label: const Text('Réessayer'),
            ),
          ],
        ),
      ),
    );
  }
}
