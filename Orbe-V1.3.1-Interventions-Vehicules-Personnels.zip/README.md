# Orbe Viewer

Application Android (Flutter) qui donne un accès direct à la page
**Notifications / Accusés de réception** d'Orbe (outil de gestion NexSIS
pour sapeurs-pompiers), sans avoir à naviguer manuellement dans le
navigateur.

## Fonctionnalités

- Ouvre directement la bonne page Orbe au lancement (session/cookies
  persistants, pas besoin de se reconnecter à chaque fois).
- Surveillance automatique : scanne périodiquement la page à la recherche
  d'un nom de pompier donné sur une carte "Engin en attente", et envoie une
  notification Android locale (véhicule, rôle occupé, motif, numéro
  d'intervention) dès qu'il apparaît.
- Peut être lancée avec un paramètre (`watch_name`) par une autre
  application (ex: un outil de surveillance de notifications qui détecte
  une alerte NexSIS), pour déclencher le scan immédiatement sans attendre
  le prochain cycle.
- Le nom à surveiller est mémorisé localement ; demandé une seule fois au
  premier lancement.
- Bouton "Ticket" : va chercher le ticket de départ complet (numéro,
  chronologie, train de départ, informations sur l'intervention) d'un
  centre de secours donné, sans avoir à naviguer manuellement sur la carte.
- Zoom réglable, correctifs d'affichage (la page Orbe n'est pas prévue à
  l'origine pour un rendu WebView embarqué).

## Prérequis

- Flutter (voir `environment.sdk` dans `pubspec.yaml` pour la version Dart
  minimale)
- Un SDK Android configuré (`compileSdk` / `targetSdk` définis dans
  `android/app/build.gradle.kts`)

## Builder l'application

```bash
flutter pub get
flutter build apk
```

L'APK généré se trouve dans `build/app/outputs/flutter-apk/`.

Pour lancer directement sur un appareil/émulateur connecté en mode debug :

```bash
flutter run
```

## ⚠️ Signature de l'APK (release)

Ce dépôt **ne contient volontairement aucun keystore ni fichier
`key.properties`** (exclus via `.gitignore`). Pour builder une version
**release** signée, il faut fournir le tien localement :

1. Générer un keystore (si tu n'en as pas déjà un) :

   ```bash
   keytool -genkey -v -keystore ~/upload-keystore.jks \
     -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```

2. Créer `android/key.properties` (non versionné) sur ce modèle :

   ```properties
   storePassword=<mot_de_passe_du_keystore>
   keyPassword=<mot_de_passe_de_la_clé>
   keyAlias=upload
   storeFile=<chemin_absolu_vers_upload-keystore.jks>
   ```

3. Adapter le bloc `signingConfigs` / `buildTypes.release` dans
   `android/app/build.gradle.kts` pour lire ce fichier (actuellement, la
   config de base signe avec la clé debug pour que `flutter run --release`
   fonctionne tel quel — à remplacer par ta propre config avant toute
   distribution).

Sans ça, `flutter build apk --release` fonctionne quand même mais produit
un APK signé avec la clé de debug (installable pour toi, mais pas destiné
à une distribution large).

## Structure du projet

```
lib/
├── main.dart                          # Point d'entrée (runApp)
├── app.dart                           # Widget racine (MaterialApp)
├── core/
│   └── constants/
│       └── orbe_constants.dart        # URLs, clés de préférences, canal natif
└── features/
    └── orbe_viewer/
        └── presentation/
            └── pages/
                └── orbe_webview_page.dart   # Écran principal (WebView + logique)

android/
└── app/
    └── src/main/kotlin/com/tomtom/orbe/
        └── MainActivity.kt            # Réception du paramètre watch_name
                                        # transmis par une autre app au lancement
```

## Intégration avec une autre application

Cette app peut être lancée avec un paramètre depuis une autre app Android,
pour lui indiquer directement quel nom surveiller :

```kotlin
val intent = Intent().apply {
    setClassName("com.tomtom.orbe", "com.tomtom.orbe.MainActivity")
    putExtra("watch_name", "Prénom NOM")
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
startActivity(intent)
```

Si Orbe Viewer est déjà ouverte en arrière-plan, `MainActivity.onNewIntent`
prend le relais et déclenche un scan immédiat avec le nouveau nom.

## Surveillance NexSIS

Orbe peut maintenant être réveillé automatiquement lorsqu'une notification est publiée par NexSIS (`bio.aum.opsready.nexsis`). Orbe ne cherche pas le véhicule dans le texte NexSIS : il utilise la notification uniquement comme déclencheur, puis recherche immédiatement le nom cible dans la page **Engin en attente** d'Orbe.

### Première activation

Dans Orbe, appuyer sur **NexSIS** pour ouvrir les réglages Android des accès aux notifications, puis autoriser **Orbe — Surveillance NexSIS**.

Le contrôle périodique reste actif en sécurité, mais il passe de 25 à 60 secondes. Le chemin rapide est désormais :

`Notification NexSIS → réveil d'Orbe → scan immédiat → véhicule / rôle / motif`
