package com.tomtom.orbe

import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.tomtom.orbe/intent"
    private var methodChannel: MethodChannel? = null
    private val EXTRA_WATCH_NAME = "watch_name"
    private val EXTRA_NEXSIS_NOTIFICATION = "nexsis_notification"

    // Si NexSIS réveille Orbe avant que Flutter ait installé son handler,
    // on garde l'événement pour le transmettre dès que Dart le demande.
    private var pendingNexsisNotification = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL,
        )
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getWatchName" -> result.success(intent?.getStringExtra(EXTRA_WATCH_NAME))
                "getPendingNexsisNotification" -> {
                    val pending = pendingNexsisNotification ||
                        intent?.getBooleanExtra(EXTRA_NEXSIS_NOTIFICATION, false) == true
                    pendingNexsisNotification = false
                    intent?.removeExtra(EXTRA_NEXSIS_NOTIFICATION)
                    result.success(pending)
                }
                "openNotificationListenerSettings" -> {
                    startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        val name = intent.getStringExtra(EXTRA_WATCH_NAME)
        if (!name.isNullOrBlank()) {
            methodChannel?.invokeMethod("onWatchNameUpdated", name)
        }

        if (intent.getBooleanExtra(EXTRA_NEXSIS_NOTIFICATION, false)) {
            intent.removeExtra(EXTRA_NEXSIS_NOTIFICATION)
            if (methodChannel != null) {
                methodChannel?.invokeMethod("onNexsisNotification", null)
            } else {
                pendingNexsisNotification = true
            }
        }
    }
}
