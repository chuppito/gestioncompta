package com.tomtom.orbe

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Réveille Orbe dès qu'une notification NexSIS est publiée.
 *
 * On ne cherche volontairement pas le nom dans le texte de NexSIS : NexSIS
 * annonce surtout qu'une intervention est disponible. C'est Orbe qui possède
 * la vue "Engin en attente" permettant de déterminer le véhicule et le motif.
 */
class NexsisNotificationListener : NotificationListenerService() {
    companion object {
        private const val NEXSIS_PACKAGE = "bio.aum.opsready.nexsis"
        private const val EXTRA_NEXSIS_NOTIFICATION = "nexsis_notification"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != NEXSIS_PACKAGE) return

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(EXTRA_NEXSIS_NOTIFICATION, true)
        }

        try {
            startActivity(launchIntent)
        } catch (_: Exception) {
            // Si Android refuse momentanément le lancement en avant-plan,
            // le scan périodique d'Orbe reste le filet de sécurité.
        }
    }
}
